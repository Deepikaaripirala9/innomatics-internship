import heapq

class Solution:
    def maxProduct(self, nums: list[int]) -> int:
        
        pq = []
        for num in nums:
            heapq.heappush(pq, -num)

        product = 1
        product *= (-heapq.heappop(pq) - 1)
        product *= (-heapq.heappop(pq) - 1)

        return product
