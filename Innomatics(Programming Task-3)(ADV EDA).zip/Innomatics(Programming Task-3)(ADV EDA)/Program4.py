class Solution:
    def steps(self, num: int) -> int:
        if num == 0:
            return 0
        return (self.steps(num // 2) if num % 2 == 0 else self.steps(num - 1)) + 1

    def numberOfSteps(self, num: int) -> int:
        return self.steps(num)
