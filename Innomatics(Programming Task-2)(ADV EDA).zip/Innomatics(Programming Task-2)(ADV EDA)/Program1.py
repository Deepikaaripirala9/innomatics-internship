class Solution:
    def defangIPaddr(self, address: str) -> str:
        update = address.split(".") 
        result = ""
        for i in range(len(update)):
            result += update[i]
            if i != len(update) - 1:
                result += "[.]"
        return result
