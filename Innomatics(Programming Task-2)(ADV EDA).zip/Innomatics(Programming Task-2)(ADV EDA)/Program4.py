class Solution:
    def smallerNumbersThanCurrent(self, nums: list[int]) -> list[int]:
        
        newArray = [0] * 101
        
       
        for num in nums:
            newArray[num] += 1
        
        
        for i in range(1, 101):
            newArray[i] += newArray[i - 1]
        
        
        result = []
        for num in nums:
            if num == 0:
                result.append(0)
            else:
                result.append(newArray[num - 1])
        
        return result
